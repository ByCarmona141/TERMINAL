function cursor
    if test (count $argv) -eq 0
        set target (wslpath -w (pwd))
    else
        set target (wslpath -w $argv[1])
    end

    nohup "/mnt/c/Users/bycar/AppData/Local/Programs/cursor/Cursor.exe" $target >/dev/null 2>&1 &
end
