# Disable default vi prompt
