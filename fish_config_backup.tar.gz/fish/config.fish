# PATH
set -gx PATH $PATH /home/bycarmona141/.local/bin

if status is-interactive
    # Commands to run in interactive sessions can go here
	
	# Limpiar pantalla
	clear

	# Logo Personalizado
	figlet -f big "BYCARMONA141" | lolcat -S 145

	# FASTFETCH para Info del sistema con ASCII
        fastfetch --config ~/.config/fastfetch/config_bycarmona.jsonc
end

# OH MY POSH (Tema Clean Detailed)
oh-my-posh init fish --config ~/.cache/oh-my-posh/themes/clean-detailed.omp.json | source

# pnpm
set -gx PNPM_HOME "/home/ByCarmona141/.local/share/pnpm"
if not string match -q -- $PNPM_HOME $PATH
  set -gx PATH "$PNPM_HOME" $PATH
end
# pnpm end

eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv fish)"

# opencode
fish_add_path /home/ByCarmona141/.opencode/bin

# lsd
alias ls='lsd'
alias ls-la='lsd -la'

# Cursor
function cursor
    set winpath (wslpath -w (pwd))
    powershell.exe -NoProfile -Command "Start-Process -FilePath 'C:\Users\ByCar\AppData\Local\Programs\cursor\_\Cursor.exe' -ArgumentList '$winpath' -WorkingDirectory 'C:\'"
end

# PHPStorm
alias phpstorm='"/mnt/c/Program Files/JetBrains/PhpStorm 2026.2.0.1/bin/phpstorm64.exe"'

# WebStorm
alias webstorm='"/mnt/c/Program Files/JetBrains/WebStorm 2025.2.3/bin/webstorm64.exe"'
